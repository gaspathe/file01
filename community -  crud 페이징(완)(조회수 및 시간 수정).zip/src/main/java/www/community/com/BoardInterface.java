package www.community.com;

public interface BoardInterface {

	public String boardReadInfo();
	public String boardReadSave();
	public String boardReadModie();
	public String boardReadDelete();
	
	
	
}
