package www.community.com.freeboard;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FreeBoardService {

	@Autowired
	private FreeBoardRepository freeBoardRepository;
	
	public List<FreeBoardVo> getBoardList () {
		return freeBoardRepository.getBoardList();
	}
	
	public List<FreeBoardVo> getBoardList (FreeBoardVo boardVo) {
		return freeBoardRepository.getBoardList(boardVo);
	}
	
	public int getBoardCount(FreeBoardVo boardVo) {
		return freeBoardRepository.getBoardCount(boardVo);
	}
	

	public FreeBoardVo readBoard (int index) {
		return freeBoardRepository.readText(index);
	}
	
	public int registerText(FreeBoardVo boardVo) {
		
		return freeBoardRepository.registerText(boardVo);
	}
	
	// 혼자해보기
	
	public int updateText(FreeBoardVo boardVo) {
		
		return freeBoardRepository.updateText(boardVo);
	}
	
	public int deleteText(FreeBoardVo boardVo) {
		
		return freeBoardRepository.deleteText(boardVo);
	}

	public int countUpdateBoard(int index) {
		return freeBoardRepository.countUpdateBoard(index);
	}

	
}
