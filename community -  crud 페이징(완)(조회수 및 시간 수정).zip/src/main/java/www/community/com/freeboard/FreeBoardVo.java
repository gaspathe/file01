package www.community.com.freeboard;

public class FreeBoardVo extends Pagination{
	
	private int index;
	private String image;
	private String title;
	private String contents;
	private String regName;
	private String regDate;
	private int count;
	private int recommand;
	
	private String search_text;
	private String addpost;
	

	public int getIndex() {
		return index;
	}


	public void setIndex(int index) {
		this.index = index;
	}


	public String getImage() {
		return image;
	}


	public void setImage(String image) {
		this.image = image;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getContents() {
		return contents;
	}


	public void setContents(String contents) {
		this.contents = contents;
	}


	public String getRegName() {
		return regName;
	}


	public void setRegName(String regName) {
		this.regName = regName;
	}


	public String getRegDate() {
		return regDate;
	}


	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}


	public int getCount() {
		return count;
	}


	public void setCount(int count) {
		this.count = count;
	}


	public int getRecommand() {
		return recommand;
	}


	public void setRecommand(int recommand) {
		this.recommand = recommand;
	}


	public String getSearch_text() {
		return search_text;
	}


	public void setSearch_text(String search_text) {
		this.search_text = search_text;
	}


	public String getAddpost() {
		return addpost;
	}


	public void setAddpost(String addpost) {
		this.addpost = addpost;
	}
	
	
}
