package www.community.com.freeboard;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class FreeBoardRepository {
	
	@Autowired
	SqlSessionTemplate sqlSessionTemplate;
	
	public List<FreeBoardVo> getBoardList() {
		return sqlSessionTemplate.selectList("FreeBoard_mapper.selectFreeBoard");
	}
	
	public List<FreeBoardVo> getBoardList(FreeBoardVo boardVo) {
		return sqlSessionTemplate.selectList("FreeBoard_mapper.selectFreeBoardBySearch",boardVo);
	}
	
	public int getBoardCount(FreeBoardVo boardVo) {
		return sqlSessionTemplate.selectOne("FreeBoard_mapper.selectFreeBoardCount",boardVo);
	}
	

	public FreeBoardVo readText(int index) {
		return sqlSessionTemplate.selectOne("FreeBoard_mapper.readText",index);
	}
	
	public int registerText(FreeBoardVo boardVo) {
		return sqlSessionTemplate.insert("FreeBoard_mapper.registerText",boardVo);
	}
	
	// 혼자 해보기
	
	public int updateText(FreeBoardVo boardVo) {
		return sqlSessionTemplate.update("FreeBoard_mapper.updateText",boardVo); }
	
	
	 public int deleteText(FreeBoardVo boardVo) { 
		 return sqlSessionTemplate.delete("FreeBoard_mapper.deleteText",boardVo); }

	public int countUpdateBoard(int index) {
		return sqlSessionTemplate.update("FreeBoard_mapper.updateCount",index); }


}
