package www.community.com.freeboard;

import java.time.LocalDateTime;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Handles requests for the application home page.
 */

@Controller
public class FreeBoardController {

	private static final Logger logger = LoggerFactory.getLogger(FreeBoardController.class);
	
	@Autowired
	FreeBoardService freeBoardService;
	// 메인
	@RequestMapping(value = "/freeboard", method = RequestMethod.GET)
	public String freeboard(Locale locale, Model model, 
			FreeBoardVo boardVo
		) {
		
		// 페이징 
		int listCnt = freeBoardService.getBoardCount(boardVo);
		boardVo.setListCnt(listCnt);
        /** 1. 총 페이지 수 **/
		boardVo.setPageCnt(listCnt);
        /** 2. 총 블럭(range)수 **/
		boardVo.setRangeCnt(boardVo.getPageCnt());
        /** 3. 블럭(range) setting **/
		boardVo.rangeSetting(boardVo.getCurPage());
        /** DB 질의를 위한 startIndex 설정 **/
		boardVo.setStartIndex(boardVo.getCurPage());
		
		System.out.println(boardVo);
		
		model.addAttribute("BoardList", freeBoardService.getBoardList(boardVo));
		model.addAttribute("boardVo", boardVo);
		
		return "freeboard/freeboardmain";
	}
	
	@RequestMapping(value = "/freeboard/add", method = RequestMethod.GET)
	public String freeboardadd( Model model,FreeBoardVo boardVo) {
		model.addAttribute("boardVo", boardVo);

		return "freeboard/freeboardadd";
	}
	
	
	@RequestMapping(value = "/freeboard/add/procces", method = RequestMethod.GET)
	public String freeboardaddprocces( Model model, FreeBoardVo boardVo) {
		freeBoardService.registerText(boardVo);
		return "redirect:/freeboard";
	}
	
	
	@RequestMapping(value = "/freeboard/read", method = RequestMethod.GET)
	public String freeboardRead( Model model,int index) {
		freeBoardService.countUpdateBoard(index);
		FreeBoardVo boardVo = freeBoardService.readBoard(index);
		model.addAttribute("boardVo", boardVo);
		return "freeboard/freeboardinpost";
	}
	
	// 혼자 해보기
	//업데이트 화면 전환
	@RequestMapping(value = "/freeboard/update", method = RequestMethod.GET)
	public String freeboardupdate( Model model, FreeBoardVo boardVo) {
		FreeBoardVo readboardVo = freeBoardService.readBoard(boardVo.getIndex());
		model.addAttribute("boardVo", readboardVo);
		return "freeboard/freeboardupdate";
	}
	
	// 업데이트 기능 컨트롤러
	@RequestMapping(value = "/freeboard/update/procces", method = RequestMethod.GET)
	public String freeboardupdateprocces( Model model, FreeBoardVo boardVo) {
		System.out.println(boardVo);
		freeBoardService.updateText(boardVo);
		return "redirect:/freeboard";
	}
	
	//   /freeboard/delete
	@RequestMapping(value = "/freeboard/delete", method = RequestMethod.GET)
	public String freeboarddelete( Model model, FreeBoardVo boardVo) {
		freeBoardService.deleteText(boardVo);
		return "redirect:/freeboard";
	}
}
